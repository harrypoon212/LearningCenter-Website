<?php
include 'inc/header.php';


/*student login page/*
/*
Page code: 4.1
Who can access: Tenant
Description: The page where user lands after login.
*/

//customer_only();


// select all consignment stores if they have at least 1 active product.
/*$qs = "select consignmentstore.consignmentStoreID, count(*) as p, consignmentStore.consignmentStoreName from consignmentstore inner join goods
on consignmentStore.consignmentStoreID = goods.consignmentStoreID and goods.status = 1
group by goods.consignmentStoreID";

$query = mysqli_query($conn, $qs) or die(mysqli_error($conn));*/

print("

<div class='container'>
<div class='row'>
<div class='col-12 my-2'>
<h4 class='text-secondary'>Progress Bar</h4>
</div>
</div>
</div>

<div class='container'>




<div class='row mt-3'>
<table class='table table-hover'>
<tr>
<th>Course Name</th>
<th>Class ID</th>
<th>Progress Bar</th>
</tr>
");
	$sql="select * from student_attendance,student,timetable,class,class_category
	WHERE student.student_ID=student_attendance.student_ID AND 
	timetable.timetable_ID=student_attendance.timetable_ID AND
	timetable.class_ID=class.class_ID AND
	class.category_ID=class_category.category_ID AND
	student_attendance.student_ID='".$_SESSION['student_ID']."'";
	$query = mysqli_query($conn, $sql)or die(mysqli_error($conn));
	while($result = mysqli_fetch_assoc($query)){
		echo"
		<tr>
		<td>".$result['name']."</td>
		<td>".$result['class_ID']."</td>
		<td>
		<ol class='progtrckr' data-progtrckr-steps='".$result['total_lessons']."'>
        <div class='scrollmenu'>";
		for($i=1 ; $i<=$result['total_lessons'] ; $i++){
	    if($result['lesson']==$i)
			if($result['is_late']==0){
        echo"<li class='progtrckr-done'>Lesson.".$i."</li>";
			}else{
				 echo"<li class='progtrckr-late'>Lesson.".$i."</li>";
			}
	    else
		echo"<li class='progtrckr-todo'>Lesson.".$i."</li>";
        }
		echo"
        </div>
        </ol>
		</td>
		</tr>
		";
}


		print("
		<tr>
		<td></td>
		<td>
		</td>
		</tr>
		");


print("
</table>
</div>
</div>
");
?>

<?php
include 'inc/footer.php';
?>
