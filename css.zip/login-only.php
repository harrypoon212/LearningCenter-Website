<?php
include 'inc/header.php';

/*
Page code: 8.2
Who can access: Users except tenant
*/


?>

<div class="container">
	<div class="card col-md-6 mx-auto mt-4">
		<div class="card-body text-center">
			<div class="">
				<i class="fa fa-ban fa-3x" aria-hidden="true"></i>
			</div>
			<div class="">
				This page is for logged in users only.
			</div>
		</div>
	</div>
</div>

<?php
include 'inc/footer.php';
?>
