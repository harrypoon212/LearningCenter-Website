<?php
//print_post_message();
//mysqli_free_result();
//mysqli_close();
?>

<div class="bg-primary">
	<div class="container my-3">
		<div class="row" style="">
			<div class="col-12 my-3 text-center text-secondary text-center">
				© 2020 All Rights Reserved
			</div>
		</div>
	</div>
</div>

</body>

</html>