<?php
include 'inc/header.php';

/*
Page code: 1.9
Who can access: Anonymous users
*/

session_unset();
header("Location: index.php");

?>

<?php
include 'inc/footer.php';
?>
